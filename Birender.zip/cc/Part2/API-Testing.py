import requests
import json

def callBadges():
    url="https://api.stackexchange.com/2.2/badges?order=desc&sort=rank&site=stackoverflow"
    r = requests.get(url)
    print(r.status_code)
    print(type(r.json()))

    data = r.json()

    #print(data['items'])
    badgeId_list = []
    for item in data['items']:
        #print(item['badge_id'])
        badgeId_list.append(item['badge_id'])
    
    for id in badgeId_list:
        #print(x)
        callBadges_withId(id)


def callBadges_withId(id):
    url = f'https://api.stackexchange.com/2.2/badges/{id}?order=desc&sort=rank&site=stackoverflow'
    r = requests.get(url)
    print(r.status_code)
    print(r.json())


def callBadges_recepients():
    url = "https://api.stackexchange.com/2.2/badges/recipients?site=stackoverflow"
    r = requests.get(url)
    print(r.status_code)
    print(r.json())

def callBadges_tags():
    url = 'https://api.stackexchange.com/2.2/badges/tags?order=desc&sort=rank&site=stackoverflow'
    r = requests.get(url)
    print(r.status_code)
    print(r.json())

	
callBadges()
callBadges_recepients()
callBadges_tags()
