Part 1: Front-End Automation 

1. Open the maven project in Eclipse, its based on Page Object Model framework.
2. Go to package com.qa.config in src/main/java/
3. Edit config.properties for "chromeDriverPath" location
4. Right click on testNG.xml and run as TestNG Suite
5. Or change directory to "stackoverflow-Front-End-Testing" and execute "mvn clean test"

Tools and Technologies [for details refer pom.xml]:
	Eclipse
	Selenium webdriver
	Maven  - Dependencies
	TestNG

Code is also available on GitHub:
1. Clone and execute the test as below:

git clone https://github.com/bkumar2018/stackoverflow-Front-End-Testing.git
cd stackoverflow-Front-End-Testing
mvn clean test


Code Workflow documentation:

1. Maven project based on POM
2. Source code are in folder "src/main/java" and have following packages:
	com.qa.base
		TestBase.java	[This is base class, all other classes extends this class]
		
	com.qa.config
		config.properties  [Global environment configuration]
		
	com.qa.pages			[Java class for all web pages its uses Pagefactory the inbuild POM for selenium webdriver]
		HomePage.java
		QuestionsPage.java
		TagsPage.java
		
	com.qa.util
		TestUtil.java 		[This is for all the test utilities]

3. All test cases are in folder "src/test/java" and have following package:
	
	com.qa.testcases
		HomePageTest.java
		QuestionsPageTest.java
		TagsPageTest.java
	
	
